# MotorPHGUI2
Updated Version of MotorPGUI using frames classes in Netbeans Apache.
Group 1 - CP2 A2101